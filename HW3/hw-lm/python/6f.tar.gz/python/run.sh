#printf "add2.7 ********************"
#./textcat.py add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/test/english/*/*
#./textcat.py add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/test/spanish/*/*
#printf "backoff_2.7========================"
#=======
#./python/textcat.py backoff_add2.7 lexicons/words-10.txt All_Training/en.1K All_Training/sp.1K english_spanish/test/english/*/*
#./python/textcat.py backoff_add2.7 lexicons/words-10.txt All_Training/en.1K All_Training/sp.1K english_spanish/test/spanish/*/*

#./textcat.py add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
#./textcat.py add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py backoff_add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/test/english/*/*
#./textcat.py backoff_add2.7 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/test/spanish/*/*
#printf "=================="
#./textcat.py backoff_add1 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py backoff_add1 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
#printf "=================="
#./textcat.py backoff_add5 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py backoff_add5 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
#printf "=================="
#./textcat.py backoff_add100 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py backoff_add100 ../lexicons/words-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
printf "=================="
#./textcat.py loglinear1 ../lexicons/chars-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py loglinear1 ../lexicons/chars-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
./fileprob.py loglinear1 ../lexicons/chars-10.txt en.1K
./fileprob.py loglinear8 ../lexicons/chars-10.txt en.1K
