for C in  0.000001 4 5 9 10 20 30
  do
    printf "C is $C \n"
    for len in 10
      do
        printf "lexicon length: $len\n"
          for train_len in 1K
            do
              printf "train length is $train_len"
              ./textcat.py loglinear$C ../lexicons/chars-$len.txt en.$train_len sp.$train_len ../english_spanish/dev/english/*/*
              ./textcat.py loglinear$C ../lexicons/chars-$len.txt en.$train_len sp.$train_len ../english_spanish/dev/spanish/*/*
            done
        printf "============================\n"
      done
  done

