#./textcat.py loglinear1 ../lexicons/chars-10.txt en.1K sp.1K ../english_spanish/dev/english/*/*
#./textcat.py backoff_add2.7 ../lexicons/chars-10.txt en.1K sp.1K ../english_spanish/dev/spanish/*/*
./fileprob.py loglinear1 ../lexicons/chars-10.txt sp.1K
